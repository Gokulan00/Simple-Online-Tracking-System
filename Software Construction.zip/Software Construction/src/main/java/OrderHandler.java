import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;
import com.google.cloud.firestore.*;

import java.io.IOException;
import java.io.OutputStream;

public class OrderHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        String path = exchange.getRequestURI().getPath();
        String orderId = path.split("/")[2];

        String response = "";

        try {
            Firestore db = FirebaseConfig.getFirestore();

            DocumentSnapshot doc = db.collection("orders")
                    .document(orderId)
                    .get()
                    .get();

            if (doc.exists()) {
                response = "{ \"status\": \"" + doc.getString("status") + "\", " +
                           "\"product\": \"" + doc.getString("product") + "\" }";
            } else {
                response = "{ \"error\": \"Order not found\" }";
            }

        } catch (Exception e) {
            response = "{ \"error\": \"Server error\" }";
        }

        // 🔥 CORS fix
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");

        exchange.sendResponseHeaders(200, response.length());
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}