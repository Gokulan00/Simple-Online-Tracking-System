public class Order {
    private int orderId;
    private String customerName;
    private String productName;
    private int quantity;
    private String status;
    public Order(int orderId, String customerName, String productName, int quantity) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.productName = productName;
        this.quantity = quantity;
        this.status = "Placed";
    }
    public int getOrderId() {
        return orderId;
    }
    public String getCustomerName() {
        return customerName;
    }
    public String getProductName() {
        return productName;
    }
    public int getQuantity() {
        return quantity;
    }
    public String getStatus() {
        return status;
    }
}