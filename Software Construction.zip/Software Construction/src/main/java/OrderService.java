import java.util.ArrayList;
import java.util.List;

public class OrderService {
    private int orderCounter = 1000;
    private List<Order> orders = new ArrayList<>();
    public Order placeOrder(String customerName, String productName, int quantity) {
        orderCounter++;
        Order newOrder = new Order(orderCounter, customerName, productName, quantity);
        orders.add(newOrder);
        return newOrder;
    }
    public List<Order> getAllOrders() {
        return orders;
    }
}